"""Checks that the app's engine reproduces the capstone notebook's published results.
Run:  python tests/test_parity.py <path to the Statista export .xlsx>"""
import json, sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import analytics as an

# The Statista export is licensed and not in the repository: pass its path as the first argument.
workbook = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "data" / "statista_fresh_fruits_china.xlsx"
if not workbook.exists():
    sys.exit("Usage: python tests/test_parity.py <path to the Statista export .xlsx>")
mk = an.load_market(workbook)
facts, plan = an.load_company(ROOT / "data" / "pagoda_facts.csv", ROOT / "data" / "analyst_plan.csv")
model = an.build_model(facts, plan)
dq, outliers = an.quality_checks(mk)
bt, _ = an.backtest(mk); fc = an.market_forecast(mk)
cal = an.calibration(model)
res = {b: an.summarise(model, an.simulate(model, an.make_ranges(model, b))) for b in ("neutral", "downside")}
lev = an.lever_values(model)

# internal invariants
assert cal.revenue_gap_pct.abs().max() < 0.5 and cal.net_profit_gap.abs().max() < 3, "model no longer reproduces the analyst plan"
assert fc.inside_envelope.all()
assert bt.index[0] == "Combination"
assert (dq.result == "pass").sum() >= 7
print("invariants ok |", f"calibration gap {cal.revenue_gap_pct.abs().max():.2f}% |", f"P(profit) neutral {res['neutral'].prob_profit_pct.round(1).tolist()} downside {res['downside'].prob_profit_pct.round(1).tolist()}")

ref_path = ROOT.parent / "outputs" / "results.json"
if ref_path.exists():
    ref = json.loads(ref_path.read_text()); n = 0
    def close(a, b, tol, what):
        global n; n += 1
        assert abs(a - b) <= tol, f"{what}: app {a} vs notebook {b}"
    for b in ("neutral", "downside"):
        for row in ref["sim"]["results"][b]:
            y = row["year"]
            for k in ("prob_profit_pct", "net_profit_median", "net_profit_p10", "net_profit_p90", "revenue_median"):
                close(res[b].loc[y, k], row[k], 1e-6, f"{b} {y} {k}")
    for row in ref["forecast"]:
        for k in ("this_study", "linear_path", "exponential_path", "statista"):
            close(fc.loc[row["year"], k], row[k], 1e-6, f"forecast {row['year']} {k}")
    for row in ref["backtest"]:
        close(bt.loc[row["method"], "mape_pct"], row["mape_pct"], 1e-6, f"backtest {row['method']}")
    close(lev["gm_point"], ref["sim"]["levers"]["+1 pt gross margin"], 1e-6, "lever gm"); close(lev["stores_per_gm_point"], ref["sim"]["stores_per_gm_point"], 1e-6, "stores per point")
    sh = an.share_table(mk, facts)
    for row in ref["share"]:
        close(sh.loc[row["year"], "share_proxy_pct"], row["share_proxy_pct"], 1e-6, f"share {row['year']}")
    rob = an.robustness(model)
    for row in ref["sim"]["robustness"]:
        match = rob[[i.split(" (")[0] == row["scenario"].split(" (")[0] for i in rob.index]]
        close(match.iloc[0]["p_2026"], row["prob_profit_2026_pct"], 1e-6, f"robustness {row['scenario']}")
    chk, _ = an.first_half_2026_check(model, facts)
    for row in ref.get("first_half_2026", []):
        close(chk.loc[row["driver"], "pct_neutral"], row["percentile_in_neutral_range"], 1e-6, f"1H26 check {row['driver']}")
    print(f"parity with notebook: {n} values match")
