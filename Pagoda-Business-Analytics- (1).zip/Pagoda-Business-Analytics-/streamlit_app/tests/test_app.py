"""Headless smoke test: the app renders, and the simulator responds to its controls."""
import sys
from pathlib import Path
from streamlit.testing.v1 import AppTest
ROOT = Path(__file__).resolve().parent.parent
at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=120).run()
assert not at.exception, [e.value for e in at.exception]
assert not at.error, [e.value for e in at.error]
metrics = {m.label: m.value for m in at.metric}
print("metrics:", metrics)
before = metrics["2026: chance of profit"]
at.slider(key="sl_gm").set_value(-1.0).run()
assert not at.exception, [e.value for e in at.exception]
after = {m.label: m.value for m in at.metric}["2026: chance of profit"]
print("2026 chance of profit: at plan", before, "| margin 1 pt below plan", after)
assert before != after
at.radio(key="belief").set_value("It is the best case").run(); at.slider(key="sl_gm").set_value(0.0).run()
assert not at.exception, [e.value for e in at.exception]
print("best-case view:", {m.label: m.value for m in at.metric if "chance" in m.label})
print("tabs:", [t.label for t in at.tabs], "| warnings:", len(at.warning), "| dataframes:", len(at.dataframe))
